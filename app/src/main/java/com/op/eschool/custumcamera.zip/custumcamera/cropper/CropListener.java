package com.op.eschool.custumcamera.cropper;

import android.graphics.Bitmap;


public interface CropListener {

    void onFinish(Bitmap bitmap);

}
